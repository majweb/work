<?php

return [
    'foundations' => 'Fundacje',
];
