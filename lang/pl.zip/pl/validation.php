<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Validation Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines contain the default error messages used by
    | the validator class. Some of these rules have multiple versions such
    | as the size rules. Feel free to tweak each of these messages here.
    |
    */

    "accepted"=>"Pole :attribute musi zostać zaakceptowane.",
    "accepted_if"=>"Pole :attribute musi zostać zaakceptowane gdy :other ma wartość :value.",
    "active_url"=>"Pole :attribute jest nieprawidłowym adresem URL.",
    "after"=>"Pole :attribute musi być datą późniejszą od :date.",
    "after_or_equal"=>"Pole :attribute musi być datą nie wcześniejszą niż :date.",
    "alpha"=>"Pole :attribute może zawierać jedynie litery.",
    "alpha_dash"=>"Pole :attribute może zawierać jedynie litery, cyfry i myślniki.",
    "alpha_num"=>"Pole :attribute może zawierać jedynie litery i cyfry.",
    "array"=>"Pole :attribute musi być tablicą.",
    "ascii"=>"Pole :attribute może zawierać tylko jednobajtowe znaki alfanumeryczne i symbole.",
    "attached"=>"Pole :attribute jest już dołączone.",
    "before"=>"Pole :attribute musi być datą wcześniejszą od :date.",
    "before_or_equal"=>"Pole :attribute musi być datą nie późniejszą niż :date.",
    "between.array"=>"Pole :attribute musi składać się z :min - :max elementów.",
    "between.file"=>"Pole :attribute musi zawierać się w granicach :min - :max kilobajtów.",
    "between.numeric"=>"Pole :attribute musi zawierać się w granicach :min - :max.",
    "between.string"=>"Pole :attribute musi zawierać się w granicach :min - :max znaków.",
    "boolean"=>"Pole :attribute musi mieć wartość logiczną prawda albo fałsz.",
    "can"=>"Pole :attribute zawiera nieautoryzowaną wartość.",
    "confirmed"=>"Potwierdzenie pola :attribute nie zgadza się.",
    "contains"=>"Pole :attribute nie zawiera wymaganego elementu.",
    "current_password"=>"Hasło jest nieprawidłowe.",
    "date"=>"Pole :attribute nie jest prawidłową datą.",
    "date_equals"=>"Pole :attribute musi być datą równą :date.",
    "date_format"=>"Pole :attribute nie jest w formacie :format.",
    "decimal"=>"Pole :attribute musi mieć :decimal miejsc po przecinku.",
    "declined"=>"Pole :attribute musi zostać odrzucone.",
    "declined_if"=>"Pole :attribute musi zostać odrzucone, gdy :other ma wartość :value.",
    "different"=>"Pole :attribute oraz :other muszą się różnić.",
    "digits"=>"Pole :attribute musi składać się z :digits cyfr.",
    "digits_between"=>"Pole :attribute musi mieć od :min do :max cyfr.",
    "dimensions"=>"Pole :attribute ma niepoprawne wymiary.",
    "distinct"=>"Pole :attribute ma zduplikowane wartości.",
    "doesnt_end_with"=>"Pole :attribute nie może kończyć się jednym z następujących wartości: :values.",
    "doesnt_start_with"=> "Pole :attribute nie może zaczynać się od jednego z następujących wartości: :values.",
    "email"=> "Pole :attribute nie jest poprawnym adresem e-mail.",
    "ends_with"=>"Pole :attribute musi kończyć się jedną z następujących wartości: :values.",
    "enum"=> "Pole :attribute ma niepoprawną wartość.",
    "exists"=> "Zaznaczone pole :attribute jest nieprawidłowe.",
    "extensions"=> "Pole :attribute musi mieć jedno z następujących rozszerzeń: :values.",
    "failed"=>"Błędny login lub hasło.",
    "file"=>"Pole :attribute musi być plikiem.",
    "filled"=>"Pole :attribute musi być wypełnione.",
    "gt.array"=>"Pole :attribute musi mieć więcej niż :value elementów.",
    "gt.file"=>"Pole :attribute musi być większe niż :value kilobajtów.",
    "gt.numeric"=>"Pole :attribute musi być większe niż :value.",
    "gt.string"=>"Pole :attribute musi być dłuższe niż :value znaków.",
    "gte.array"=>"Pole :attribute musi mieć :value lub więcej elementów.",
    "gte.file"=>"Pole :attribute musi być większe lub równe :value kilobajtów.",
    "gte.numeric"=>"Pole :attribute musi być większe lub równe :value.",
    "gte.string"=>"Pole :attribute musi być dłuższe lub równe :value znaków.",
    "hex_color"=>"Pole :attribute musi mieć podany prawidłowy kolor w formacie szesnastkowym.",
    "image"=>"Pole :attribute musi być obrazkiem.",
    "in"=>"Zaznaczony element :attribute jest nieprawidłowy.",
    "in_array"=>"Pole :attribute nie znajduje się w :other.",
    "integer"=>"Pole :attribute musi być liczbą całkowitą.",
    "ip"=>"Pole :attribute musi być prawidłowym adresem IP.",
    "ipv4"=>"Pole :attribute musi być prawidłowym adresem IPv4.",
    "ipv6"=>"Pole :attribute musi być prawidłowym adresem IPv6.",
    "json"=>"Pole :attribute musi być poprawnym ciągiem znaków JSON.",
    "list"=>"Pole :attribute musi być listą.",
    "lowercase"=>":Attribute musi być pisany małymi literami.",
    "lt.array"=>"Pole :attribute musi mieć mniej niż :value elementów.",
    "lt.file"=>"Pole :attribute musi być mniejsze niż :value kilobajtów.",
    "lt.numeric"=>"Pole :attribute musi być mniejsze niż :value.",
    "lt.string"=>"Pole :attribute musi być krótsze niż :value znaków.",
    "lte.array"=>"Pole :attribute musi mieć :value lub mniej elementów.",
    "lte.file"=>"Pole :attribute musi być mniejsze lub równe :value kilobajtów.",
    "lte.numeric"=>"Pole :attribute musi być mniejsze lub równe :value.",
    "lte.string"=>"Pole :attribute musi być krótsze lub równe :value znaków.",
    "mac_address"=>"Pole :attribute musi być prawidłowym adresem MAC.",
    "max.array"=>"Pole :attribute nie może mieć więcej niż :max elementów.",
    "max.file"=>"Pole :attribute nie może być większe niż :max kilobajtów.",
    "max.numeric"=>"Pole :attribute nie może być większe niż :max.",
    "max.string"=>"Pole :attribute nie może być dłuższe niż :max znaków.",
    "max_digits"=>"Pole :attribute nie może mieć więcej niż :max cyfr.",
    "mimes"=>"Pole :attribute musi być plikiem typu :values.",
    "mimetypes"=>"Pole :attribute musi być plikiem typu :values.",
    "min.array"=>"Pole :attribute musi mieć przynajmniej :min elementów.",
    "min.file"=>"Pole :attribute musi mieć przynajmniej :min kilobajtów.",
    "min.numeric"=>"Pole :attribute musi być nie mniejsze od :min.",
    "min.string"=>"Pole :attribute musi mieć przynajmniej :min znaków.",
    "min_digits"=>"Pole :attribute musi mieć co najmniej :min cyfr.",
    "missing"=>"Musi brakować pola :attribute.",
    "missing_if"=>"Jeśli :other to :value, musi brakować pola :attribute.",
    "missing_unless"=>"Musi brakować pola :attribute, chyba że :other to :value.",
    "missing_with"=>"Jeśli występuje wartość :values, musi brakować pola :attribute.",
    "missing_with_all"=>"Jeśli występuje :values, musi brakować pola :attribute.",
    "multiple_of"=>"Pole :attribute musi być wielokrotnością wartości :value",
    "next"=>"Następna &raquo;",
    "not_in"=>"Zaznaczony :attribute jest nieprawidłowy.",
    "not_regex"=>"Format pola :attribute jest nieprawidłowy.",
    "numeric"=>"Pole :attribute musi być liczbą.",
    "password"=>"Hasło jest nieprawidłowe.",
    "password.letters"=>"Pole :attribute musi zawierać przynajmniej jedną literę.",
    "password.mixed"=>"Pole :attribute musi zawierać przynajmniej jedną wielką i jedną małą literę.",
    "password.numbers"=>"Pole :attribute musi zawierać przynajmniej jedną liczbę.",
    "password.symbols"=>"Pole :attribute musi zawierać przynajmniej jeden symbol.",
    "password.uncompromised"=>"Podany :attribute pojawił się w wycieku danych. Proszę wybrać inną wartość :attribute.",
    "present"=>"Pole :attribute musi być obecne.",
    "present_if"=>"Pole :attribute musi być obecne jeżeli :other ma wartość :value.",
    "present_unless"=>"Pole :attribute musi być obecne, chyba że :other ma wartość :value.",
    "present_with"=>"Pole :attribute musi być obecne kiedy :values jest podany/a..",
    "present_with_all"=>"Pole :attribute musi być obecne kiedy :values są podane.",
    "previous"=>"&laquo; Poprzednia",
    "prohibited"=>"Pole :attribute jest zabronione.",
    "prohibited_if"=>"Pole :attribute jest zabronione, gdy :other to :value.",
    "prohibited_unless"=>"Pole :attribute jest zabronione, chyba że :other jest w :values.",
    "prohibits"=>"Pole :attribute wyklucza obecność :other.",
    "regex"=>"Format pola :attribute jest nieprawidłowy.",
    "relatable"=>"Pole :attribute nie może być powiązane z tym zasobem.",
    "required"=>"Pole :attribute jest wymagane.",
    "required_array_keys"=>"Pole :attribute musi zawierać wartości: :values.",
    "required_if"=>"Pole :attribute jest wymagane gdy :other ma wartość :value.",
    "required_if_accepted"=>"To pole jest wymagane gdy :other jest zaakceptowane.",
    "required_if_declined"=>"Pole :attribute jest wymagane gdy :other jest odrzucone.",
    "required_unless"=>"Pole :attribute jest wymagane jeżeli :other nie znajduje się w :values.",
    "required_with"=>"Pole :attribute jest wymagane gdy wartość :values jest obecna.",
    "required_with_all"=>"Pole :attribute jest wymagane gdy wszystkie wartości :values są obecne.",
    "required_without"=>"Pole :attribute jest wymagane gdy wartość :values nie jest obecna.",
    "required_without_all"=>"Pole :attribute jest wymagane gdy żadne z wartości :values nie są obecne.",
    "reset"=>"Hasło zostało zresetowane!",
    "same"=>"Pole :attribute i :other muszą być takie same.",
    "sent"=>"Przypomnienie hasła zostało wysłane!",
    "size.array"=>"Pole :attribute musi zawierać :size elementów.",
    "size.file"=>"Pole :attribute musi mieć :size kilobajtów.",
    "size.numeric"=>"Pole :attribute musi mieć :size.",
    "size.string"=>"Pole :attribute musi mieć :size znaków.",
    "starts_with"=>"Pole :attribute musi zaczynać się jedną z następujących wartości: :values.",
    "string"=>"Pole :attribute musi być ciągiem znaków.",
    "throttle"=>"Za dużo nieudanych prób logowania. Proszę spróbować za :seconds sekund.",
    "throttled"=>"Proszę zaczekać zanim spróbujesz ponownie.",
    "timezone"=>"Pole :attribute musi być prawidłową strefą czasową.",
    "token"=>"Token resetowania hasła jest nieprawidłowy.",
    "ulid"=>"Pole :attribute musi być prawidłowym identyfikatorem ULID.",
    "unique"=>"Taki :attribute już występuje.",
    "uploaded"=>"Nie udało się wgrać pliku :attribute.",
    "uppercase"=>":Attribute musi być pisany wielkimi literami.",
    "url"=>"Format pola :attribute jest nieprawidłowy.",
    "user"=>"Nie znaleziono użytkownika z takim adresem e-mail.",
    "uuid"=>"Pole :attribute musi być poprawnym identyfikatorem UUID.",

    'total_upload_size_too_high' => 'The maximum allowed size in total is :max',
    'total_upload_size_too_low' => 'The minimum allowed size in total is :min',

    'file_too_big' => 'This file is too big. Max allowed size :max',
    'file_too_small' => 'This file is too small. It should at least be :min',

    'incorrect_dimensions' => [
        'width' => 'Image width must be :width pixels',
        'height' => 'Image height must be :height pixels',
        'both' => 'Image dimensions must be :width x :height pixels',
    ],

    'width_not_between' => 'Image width must be aaaaaaaaaaaaaaaaaaasssssssssssssssbetween :min and :max pixels',
    'height_not_between' => 'Image height must be between :min and :max pixels',

    'max_items' => 'You may only upload :max item|You may only upload :max items',
    'min_items' => 'You must upload at least :min item|You must upload at least :min items',

    'extension' => 'File must be of type :extensions',
    'mime' => 'File must have mime type :mimes',
    'type' => 'You must upload a file of type :values',

    /*
    |--------------------------------------------------------------------------
    | Custom Validation Language Lines
    |--------------------------------------------------------------------------
    |
    | Here you may specify custom validation messages for attributes using the
    | convention "attribute.rule" to name the lines. This makes it quick to
    | specify a specific custom language line for a given attribute rule.
    |
    */

    'custom' => [
        'sections.*.fields.title' => [
            'required' => 'Tytuł sekcji wymagany',
            'max' => 'Tytuł sekcji musi zawierać maksymalnie 100 znaków',
            'distinct' => 'Tytuł sekcji już istnieje',
        ],
        'sections.*.fields.description' => [
            'required' => 'Treść sekcji wymagany',
            'max' => 'Tytuł sekcji musi zawierać maksymalnie 2000 znaków',
        ],
        'experiences.*.employer' => [
            'max' => 'Nazwa pracodawcy musi zawierać maksymalnie 100 znaków',
        ],
        'experiences.*.city' => [
            'max' => 'Nazwa miasta musi zawierać maksymalnie 100 znaków',
        ],
        'educations.*.school' => [
            'max' => 'Nazwa szkoły musi zawierać maksymalnie 100 znaków',
        ],
        'educations.*.city' => [
            'max' => 'Nazwa miasta musi zawierać maksymalnie 100 znaków',
        ],
        'educations.*.specialization' => [
            'max' => 'Nazwa specjalizacji musi zawierać maksymalnie 100 znaków',
        ],


    ],

    /*
    |--------------------------------------------------------------------------
    | Custom Validation Attributes
    |--------------------------------------------------------------------------
    |
    | The following language lines are used to swap our attribute placeholder
    | with something more reader friendly such as "E-Mail Address" instead
    | of "email". This simply helps us make our message more expressive.
    |
    */

    'attributes' => [
        'email'    => 'adres e-mail',
        'password' => 'hasło',
        'name'     => 'nazwa',
        'message'     => 'wiadomość',
        'agree'     => 'zgoda',
        'captcha'     => 'kod',
        'subject'     => 'temat',
    ],

];
